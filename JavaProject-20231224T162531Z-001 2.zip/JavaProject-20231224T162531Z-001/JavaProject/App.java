package JavaProject;

public class App {
    public static void main(String[] args)  {
        Loginframe frame = new Loginframe();
       frame.setVisible(true);
      
    }

}
