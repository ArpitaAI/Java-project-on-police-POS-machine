package JavaProject;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TrafficOffenseFrame extends JFrame {
    private JLabel offensesLabel;
    private JCheckBox[] offenseCheckBoxes;
    private JLabel[] offenseLabels;
    private JLabel totalFineLabel;
    private JButton prButton;

    private static final String[] OFFENSES = {
            "Helmet",
            "Over speed of driving",
            "Reckless driving",
            "Driving without insurance",
            "Parking offences",
            "Wrong side driving",
            "Without driving license"
    };

    private static final String[] FINE_AMOUNTS = {"1000TK", "2000TK", "3000TK"};

    public TrafficOffenseFrame() {
        initialize();
    }

    private void initialize() {
        setTitle("Traffic Offense Fine Calculator");
        setSize(600, 650);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        offensesLabel = new JLabel("Select type of offenses:");

        offenseCheckBoxes = new JCheckBox[OFFENSES.length];
        offenseLabels = new JLabel[OFFENSES.length];

        for (int i = 0; i < OFFENSES.length; i++) {
            offenseLabels[i] = new JLabel(OFFENSES[i]);
            offenseCheckBoxes[i] = new JCheckBox(FINE_AMOUNTS[i % FINE_AMOUNTS.length]);
        }

        totalFineLabel = new JLabel("Total Fine Amount:");

        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> calculateTotalFine()); 
        

            // okButton.addActionListener(e -> {
            //     // Action 2: Open a new frame when the button is pressed
            //     AccusedPersonHistoryApplication historyApplication = new AccusedPersonHistoryApplication();
            //     historyApplication.setVisible(true);
            // });
            JButton prButton = new JButton("Proceed");
             prButton.addActionListener(e -> {
           
                AccusedPersonHistoryApplication historyApplication = new AccusedPersonHistoryApplication();
                historyApplication.setVisible(true);
            });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(OFFENSES.length * 2 + 3, 1));

        panel.add(offensesLabel);

        for (int i = 0; i < OFFENSES.length; i++) {
            panel.add(offenseLabels[i]);
            panel.add(offenseCheckBoxes[i]);
        }

        panel.add(totalFineLabel);
        panel.add(okButton);
        panel.add(prButton);

        getContentPane().add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void calculateTotalFine() {
        int totalFine = 0;
        for (int i = 0; i < OFFENSES.length; i++) {
            if (offenseCheckBoxes[i].isSelected()) {
                totalFine += Integer.parseInt(FINE_AMOUNTS[i % FINE_AMOUNTS.length].replaceAll("[^\\d]", ""));
            }
            
        }

        totalFineLabel.setText("Total Fine Amount: " + totalFine + " TK");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TrafficOffenseFrame::new);
    }
}
