package JavaProject;
import javax.swing.*;
import java.awt.*;

public class SuccessInterface {
    public SuccessInterface(){
    // public static void main(String[] args) {
        JFrame frame = new JFrame("Success");
        frame.setSize(600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        
      
       
        
        JLabel label = new JLabel("The Case Successfully Withdrawn!");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(label, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> System.exit(0));

        JPanel panel = new JPanel();
        panel.add(closeButton);

        frame.add(panel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
    public static void main(String[] args){
        new SuccessInterface();

    }
    public void setVisible(boolean b) {
    }

   //})
}

