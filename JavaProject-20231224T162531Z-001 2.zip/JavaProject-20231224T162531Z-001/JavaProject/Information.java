package JavaProject;

import javax.swing.*;
import javax.swing.text.JTextComponent;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


  class UserData {
    private String name;
    private String licenseNumber;

    public UserData(String name, String licenseNumber) {
        this.name = name;
        this.licenseNumber = licenseNumber;
    }

    public String getName() {
        return name;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }
}


public class Information extends JFrame implements ActionListener {
    // private String name;
    // private String licenseNumber;

    public Information(String name, String licenseNumber) {
        this.name = name;
        this.licenseNumber = licenseNumber;
    }

    public String getName() {
        return name;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }
    // In Information class
// public UserData getUserDataFromFields() {
//     String name = nameField.getText();
//     String license = licenseField.getText();
//     return new UserData(name, license);
// }
protected String name;
private String licenseNumber;

public void setName(String name) {
    this.name = name;
}

public void setLicenseNumber(String licenseNumber) {
    this.licenseNumber = licenseNumber;
}


    private JTextField nameField, licenseField;
    private UserData userData;
    private JLabel jlabe2;
    private ImageIcon image2;
    public UserData getUserData() {
    return userData;
}

    public Information() {
        setTitle("Information Form");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        initComponents();
        setLayout();
        setBounds(600, 200, 600, 500);
        userData = new UserData("", "");
        image2 = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\Media\\appImage2.png");
        jlabe2 = new JLabel(image2);
        jlabe2.setBounds(0,0,600,500);
        add(jlabe2);
        // userData = new UserData("", "");
        userData = new UserData( " "," ");
       

    }

    private void initComponents() {
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Archivo Black", Font.BOLD, 16));
        JLabel licenseLabel = new JLabel("License:");
        licenseLabel.setFont(new Font("Archivo Black", Font.BOLD, 16));
        nameField = new JTextField(20);
        licenseField = new JTextField(20);
        JButton confirmButton = new JButton("Confirm");
        JButton withdrawButton = new JButton("Withdraw");
        JButton historyButton = new JButton("History");
        JButton infoButton = new JButton("Display Information");

        nameLabel.setBounds(20, 20, 100, 30);
        licenseLabel.setBounds(20, 60, 120, 30);
        nameField.setBounds(150, 20, 200, 30);
        licenseField.setBounds(150, 60, 200, 30);
        confirmButton.setBounds(80, 110, 100, 30);
        withdrawButton.setBounds(200, 110, 100, 30);
        historyButton.setBounds(320, 110, 100, 30);
        infoButton.setBounds(200,140,180,30);


        add(nameLabel);
        add(licenseLabel);
        add(nameField);
        add(licenseField);
        add(confirmButton);
        add(withdrawButton);
        add(historyButton);
        add(infoButton);

        confirmButton.addActionListener(this);
        withdrawButton.addActionListener(this);
        historyButton.addActionListener(this);
        infoButton.addActionListener(this);
    }

    private void setLayout() {
        setLayout(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // if (e.getActionCommand().equals("Confirm")) {
        //     String name = nameField.getText();
        //     String license = licenseField.getText();
        //     userData.setName(name);
        //     userData.setLicenseNumber(license);
        //     JOptionPane.showMessageDialog(this, "Information Saved: \nName: " + name + "\nLicense: " + license);
        //
        if (e.getActionCommand().equals("Confirm")) {
            String name = nameField.getText(); // Assuming nameField is a JTextField
            String license = licenseField.getText(); // Assuming licenseField is a JTextField

            // Set the retrieved name and license to the userData object
            userData.setName(name);
            userData.setLicenseNumber(license);

            JOptionPane.showMessageDialog(this, "Information Saved: \nName: " + name + "\nLicense: " + license);  
            //retirve
            // DisplayInformation displayInfo = new DisplayInformation(name, license);
            // displayInfo.setVisible(true);
        //transition to traffic offence
            TrafficOffenseFrame tFrame = new TrafficOffenseFrame();
            setVisible(true);
        } else if (e.getActionCommand().equals("Withdraw")) {
            int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to withdraw the information?",
                    "Confirmation", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                userData.setName("");
                userData.setLicenseNumber("");
                nameField.setText("");
                licenseField.setText("");
                JOptionPane.showMessageDialog(this, "Information Withdrawn");
            }
        } else if (e.getActionCommand().equals("History")) {
            String name = userData.getName();
            String license = userData.getLicenseNumber();
            if (name.isEmpty() && license.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No information saved yet.");
            } else {
                JOptionPane.showMessageDialog(this, "Name: " + name + "\nLicense: " + license, "History", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        
       
          if (e.getActionCommand().equals("Display Information")){ 
            String name = nameField.getText(); 
            String license = licenseField.getText(); 

           
            userData.setName(name);
            userData.setLicenseNumber(license);
           DisplayInformation displayInfo = new DisplayInformation(name, license);
            displayInfo.setVisible(true);
            
        }

        
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            Information frame = new Information();
        //     Information information = new Information();
        // UserData userData = information.getUserData();

        // String name = userData.getName();
        // String licenseNumber = userData.getLicenseNumber();
            frame.setVisible(true);
        });
    }
}
