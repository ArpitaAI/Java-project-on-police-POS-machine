package JavaProject;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
// import java.awt.event.ItemEvent;
// import java.util.Vector;


 


public class Loginframe extends  JFrame implements ActionListener {
   

    private JLabel userLabel = new JLabel("Username");
    //private JLabel adminLabel = new JLabel("Admin List");
    private JLabel passwordLabel = new JLabel("Password");
    private JTextField userTextField = new JTextField();
    private JPasswordField passwordField = new JPasswordField();
    private JButton loginButton = new JButton("Login");
    private JButton resetButton = new JButton("Reset");
    private JCheckBox showPassword = new JCheckBox("Show Password");
   private JButton addButton = new JButton("Add");
   private JButton deletButton = new JButton("Delet");
   private JComboBox<String> dropdown;
   //image
 
    
   
   

   private ImageIcon image;
   private JLabel imageLabel;


    public Loginframe() {
        setTitle("Adim Panel");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        initComponents();
        setLayout();
        addActionEvent();
        setBounds(300, 20, 700, 800);
       //
       image = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\Media\\appImage1.png");
       imageLabel = new JLabel(image);
       imageLabel.setBounds(0, 0, 700, 800); // Adjust x, y, width, and height as needed
       add(imageLabel);
       
    }

    private void initComponents() {
        dropdown = new JComboBox<>();
        dropdown.addItem("ghalib");
      
        //
        
        //
        userLabel.setBounds(160, 400, 100, 40);
        userLabel.setFont(new Font("Archivo Black", Font.BOLD, 16));
      
      
        passwordLabel.setBounds(160, 450, 100, 40);
        passwordLabel.setFont(new Font("Archivo Black", Font.BOLD, 16));
        userTextField.setBounds(260, 400, 150, 30);
        passwordField.setBounds(260, 450, 150, 30);
        showPassword.setBounds(260, 500, 150, 30);
        loginButton.setBounds(180, 580, 100, 30);
        resetButton.setBounds(300, 580, 100, 30);
        addButton.setBounds(180,630,100,30);
        deletButton.setBounds(300,630,100,30);
        //dropdown
        dropdown.setBounds(230, 190,290,40);
        dropdown.setBackground(Color.WHITE);
       

        //image
        
       
   

        add(userLabel);
        add(passwordLabel);
        add(userTextField);
        add(passwordField);
        add(showPassword);
        add(loginButton);
        add(resetButton);
        add(addButton);
        add(deletButton);
        //dropdown
        add(dropdown);
        
    }

    private void setLayout() {
        setLayout(null);
    }

    private void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
        addButton.addActionListener(this);
        deletButton.addActionListener(this);
    }
    

   
      




//for login

        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == loginButton) {
                String userText = userTextField.getText();
                String pwdText = new String(passwordField.getPassword());
                if ((userText.equalsIgnoreCase("ghalib") || userText.equalsIgnoreCase("xyz") || userText.equalsIgnoreCase("abc")) && pwdText.equals("12345")) {
                    JOptionPane.showMessageDialog(this, "Login Successful");
        
                    // Open a information frame after successful login
                    Information info = new Information();
                    info.setVisible(true);
                    
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Username or Password");
                }
            }
        //for reset
        
        if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
        //for showing password
        if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        }
        //for adding admin
        if(e.getSource()==addButton){
            String userInput = JOptionPane.showInputDialog(this,"Add");
                if(!userInput.isEmpty() || userInput!=null){
                    dropdown.addItem(userInput);
                }
            }
            //for deleting
            
            
            if (e.getSource() == deletButton) {
                int selectedIndex = dropdown.getSelectedIndex();
                if (selectedIndex != -1) {
                    dropdown.removeItemAt(selectedIndex);
                    JOptionPane.showMessageDialog(this, "Item deleted successfully");
                } else {
                    JOptionPane.showMessageDialog(this, "Please select an item to delete");
                }
            }
            }
            //transition class
         
    

            
    
        
        
      
        
    

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            Loginframe frame = new Loginframe();
            frame.setVisible(true);
        });
    }

    public void init() {
    } 
   
}

