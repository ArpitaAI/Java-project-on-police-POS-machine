package JavaProject;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AccusedPersonHistoryApplication extends JFrame {
   
//
private JTextField accusedNameField, vehicleRegNoField, dateField, paymentDateField, timeField;
    JTextField accusedTextField;
    private JTextField vehicleRegNoTextField;
    private JTextField offenceNameTextField;
    private JTextField locationTextField;
    private JTextField dateTextField;
    private JTextField lastDateTextField;
    private JTextField timeTextField;
    private JComboBox<String> amPmComboBox;
    private JLabel timeLabel;
    

    

    public AccusedPersonHistoryApplication() {
        setTitle("Accused Person History");
        setLayout(new GridLayout(11, 5));

  
        add(new JLabel("Accused Person:"));
        accusedTextField = new JTextField();
        add(accusedTextField);

        add(new JLabel("Vehicle Reg No:"));
        vehicleRegNoTextField = new JTextField();
        add(vehicleRegNoTextField);

        add(new JLabel("Offence Name:"));
        offenceNameTextField = new JTextField();
        add(offenceNameTextField);

        add(new JLabel("Location:"));
        locationTextField = new JTextField();
        add(locationTextField);

        add(new JLabel("Date (dd/MM/yyyy):"));
        dateTextField = new JTextField();
        add(dateTextField);

        add(new JLabel("Last Date of Payment:"));
        lastDateTextField = new JTextField();
        add(lastDateTextField);

      
        timeLabel = new JLabel("Time:");
        add(timeLabel);

        JPanel timePanel = new JPanel(new FlowLayout());
        timeTextField = new JTextField(5);
        timePanel.add(timeTextField);

        String[] amPmOptions = {"AM", "PM"};
        amPmComboBox = new JComboBox<>(amPmOptions);
        timePanel.add(amPmComboBox);

        add(timePanel);

       
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateForm()) {
                    saveHistory();
                    showNextFrame();
                    
                }
            }

            
        });
        add(okButton, BorderLayout.CENTER); 
        JButton prrButton = new JButton("Processed");
        prrButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                if(e.getSource()==prrButton){
                    VerifyCode vframe = new VerifyCode();
                    vframe.setVisible(true);
                    dispose();
                }
            }
        });
        add(prrButton, BorderLayout.CENTER);
        JButton printButton = new JButton("Print");
        printButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                if(e.getSource()==printButton){
                    JOptionPane.showMessageDialog(null, "Information has been printed");
                    

                    
                    System.out.println("Accused:  "+ accusedTextField.getText() );
                    System.out.println("Vechile Reg No. :  "+vehicleRegNoTextField.getText() );
                    System.out.println("Officer:  "+ offenceNameTextField.getText() );
                    System.out.println("Location:  "+locationTextField.getText() );
                    System.out.println("Date:  "+dateTextField.getText() );
                    System.out.println("Last Date:  "+lastDateTextField.getText() );
                    System.out.println("Time:  "+timeLabel.getText() );
                }
            }
        });
        add(printButton,BorderLayout.CENTER);


        setSize(800, 800);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private boolean validateForm() {
        if (accusedTextField.getText().isEmpty() ||
            vehicleRegNoTextField.getText().isEmpty() ||
            offenceNameTextField.getText().isEmpty() ||
            locationTextField.getText().isEmpty() ||
            dateTextField.getText().isEmpty() ||
            lastDateTextField.getText().isEmpty() ||
            timeTextField.getText().isEmpty()) {
            showError("Error! Please fill up the full form.");
            return false;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateFormat.setLenient(false);
        try {
            Date date = dateFormat.parse(dateTextField.getText());
        } catch (ParseException e) {
            showError("Error! Provide the accurate format for the date (dd/MM/yyyy).");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Form Error", JOptionPane.ERROR_MESSAGE);
    }

    private void saveHistory() {
        System.out.println("Saving history...");
    }

    private void showNextFrame() {
        System.out.println("Showing next frame...");

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AccusedPersonHistoryApplication frame = new AccusedPersonHistoryApplication();
            frame.setVisible(true);
        });
    }
}
