 package JavaProject;


// // DisplayInformation.java
import javax.swing.*;
import java.awt.*;

public class DisplayInformation extends JFrame {
    private JLabel nameLabel;
    private JLabel licenseLabel;

    public DisplayInformation(String name, String license) {
        setTitle("Display Information");
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);

        nameLabel = new JLabel("Name: " + name);
        licenseLabel = new JLabel("License: " + license);

        setLayout(new GridLayout(2, 1));
        add(nameLabel);
        add(licenseLabel);

        setVisible(true);
    }

    // Create a method to update the displayed information
    public void updateInformation(String name, String license) {
        nameLabel.setText("Name: " + name);
        licenseLabel.setText("License: " + license);
    }

    public static void main(String[] args) {
        // Assuming Information class provides the necessary information
        Information information = new Information();

        // Retrieve data from the Information class
        String name = information.getName();
        String license = information.getLicenseNumber();

        // Create and display the DisplayInformation frame with retrieved data
        SwingUtilities.invokeLater(() -> {
            DisplayInformation displayInformation = new DisplayInformation(name, license);
            displayInformation.setVisible(true);
        });
    }
}

